package org.jni.java;

/**
 * Created by xubo on 2016/6/22.
 */
public class printNTest {
    public static void main(String[] args) {
        printN p1=new printN();
        p1.print20();
    }
}

